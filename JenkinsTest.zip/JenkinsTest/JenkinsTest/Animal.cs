﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JenkinsTest
{
    public class Animal
    {
        public int GetNumberOfLegs(int number)
        {
            return number+1;
        }
    }
}
